import os
import sys
import shutil
import subprocess
import time
import ctypes
import winreg
from pathlib import Path

class EAUnlocker:
    def __init__(self):
        self.script_dir = os.path.dirname(os.path.abspath(__file__))
        self.app_data = os.path.join(os.environ['APPDATA'], r'anadius\EA DLC Unlocker v2')
        self.client_type = None # 'ea_app' or 'origin'
        self.client_path = None
        self.detect_client()

    def is_admin(self):
        try:
            return ctypes.windll.shell32.IsUserAnAdmin()
        except:
            return False

    def detect_client(self):
        # 1. Try EA Desktop
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Electronic Arts\EA Desktop") as key:
                val, _ = winreg.QueryValueEx(key, "ClientPath")
                self.client_type = 'ea_app'
                self.client_path = str(Path(val).parent.absolute())
                return
        except FileNotFoundError:
            pass

        # 2. Try Origin
        try:
            # Try WOW6432Node first (common on 64-bit windows)
            key_path = r"SOFTWARE\WOW6432Node\Origin"
            try:
                key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path)
            except FileNotFoundError:
                key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Origin")
            
            with key:
                val, _ = winreg.QueryValueEx(key, "ClientPath")
                self.client_type = 'origin'
                self.client_path = str(Path(val).parent.absolute())
                return
        except Exception:
            raise Exception("Neither EA Desktop nor Origin were found in the Registry.")

    def kill_processes(self):
        print(f"Stopping {self.client_type} processes...")
        wildcard = "Origin*" if self.client_type == 'origin' else "EA*"
        subprocess.run(f'taskkill /F /IM "{wildcard}"', shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(1)

    def clean_old_files(self):
        print("Cleaning old files...")
        files_to_remove = ['version_o.dll', 'winhttp.dll', 'winhttp_o.dll']
        for f in files_to_remove:
            path = os.path.join(self.client_path, f)
            if os.path.exists(path):
                os.remove(path)

    def install(self):
        if not self.is_admin():
            print("Error: Script must be run as Administrator to modify Program Files.")
            return False

        if not self.client_path:
            print("Error: Client not found.")
            return False

        print(f"Targeting: {self.client_type} at {self.client_path}")
        
        # 1. Prepare Paths
        src_dll = os.path.join(self.script_dir, self.client_type, 'version.dll')
        dst_dll = os.path.join(self.client_path, 'version.dll')
        src_config = os.path.join(self.script_dir, 'config.ini')
        dst_config = os.path.join(self.app_data, 'config.ini')

        # 2. Verify Payload
        if not os.path.exists(src_dll):
            print(f"Error: Missing payload at {src_dll}")
            return False
        if not os.path.exists(src_config):
            print(f"Error: Missing config at {src_config}")
            return False

        # 3. Stop App
        self.kill_processes()
        self.clean_old_files()

        # 4. Copy DLL
        try:
            shutil.copy2(src_dll, dst_dll)
            print(f"Installed version.dll to {dst_dll}")
        except Exception as e:
            print(f"Failed to copy DLL: {e}")
            return False

        # 5. EA App Specific: Scheduled Task & Staging
        if self.client_type == 'ea_app':
            parent_dir = str(Path(self.client_path).parent.absolute())
            staged_dir = os.path.join(parent_dir, 'StagedEADesktop', 'EA Desktop')
            staged_dll = os.path.join(staged_dir, 'version.dll')
            
            # Copy to Staging if it exists
            if os.path.exists(staged_dir):
                try:
                    shutil.copy2(src_dll, staged_dll)
                    print("Copied to Staging folder.")
                except:
                    pass

            # Create Task
            print("Creating Scheduled Task for persistence...")
            xcopy_cmd = f'xcopy.exe /Y "{dst_dll}" "{os.path.join(staged_dir, "*")}"'
            subprocess.run([
                'schtasks', '/Create', '/F', '/RL', 'HIGHEST', 
                '/SC', 'ONCE', '/ST', '00:00', '/SD', '01/01/2000', 
                '/TN', 'copy_dlc_unlocker', 
                '/TR', xcopy_cmd
            ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        # 6. Install Configs
        try:
            os.makedirs(self.app_data, exist_ok=True)
            shutil.copy2(src_config, dst_config)
            print("Main config installed.")
        except Exception as e:
            print(f"Failed to install config: {e}")
            return False

        return True

    def add_game_config(self, config_filename):
        """Installs a specific game config (e.g. 'g_The Sims 4.ini')"""
        src = os.path.join(self.script_dir, config_filename)
        if os.path.exists(src):
            try:
                shutil.copy2(src, self.app_data)
                print(f"Installed game config: {config_filename}")
                return True
            except Exception as e:
                print(f"Failed to copy game config: {e}")
        else:
            print(f"Game config not found: {config_filename}")
        return False

if __name__ == "__main__":
    # Check for Admin rights immediately
    if not ctypes.windll.shell32.IsUserAnAdmin():
        # Re-run the script with Admin rights silently
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, " ".join(sys.argv), None, 1)
        sys.exit()

    try:
        unlocker = EAUnlocker()
        success = unlocker.install()
        
        if success:
            # Auto-detect and install any g_*.ini files in the current folder
            for file in os.listdir(unlocker.script_dir):
                if file.startswith("g_") and file.endswith(".ini"):
                    unlocker.add_game_config(file)
            print("\nInstallation Complete.")
        else:
            print("\nInstallation Failed.")
            
    except Exception as e:
        print(f"Critical Error: {e}")
    
    # Optional: Keep window open for a few seconds to see result
    time.sleep(3)